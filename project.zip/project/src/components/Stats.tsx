import React from 'react';
import { TrendingUp, Award, Globe, Heart } from 'lucide-react';

const stats = [
  {
    icon: TrendingUp,
    value: '2M+',
    label: 'Free Learners',
    description: 'Students learning without paying a cent'
  },
  {
    icon: Award,
    value: '500K+',
    label: 'Free Certificates',
    description: 'Certificates earned at no cost'
  },
  {
    icon: Globe,
    value: '190+',
    label: 'Countries',
    description: 'Free education reaching worldwide'
  },
  {
    icon: Heart,
    value: '100%',
    label: 'Always Free',
    description: 'Our commitment to free education'
  }
];

const Stats = () => {
  return (
    <section className="py-20 bg-gradient-to-r from-emerald-600 to-teal-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Join Millions Learning for Free
          </h2>
          <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
            Be part of a global community that believes education should be free and accessible to everyone, everywhere.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <div
                key={index}
                className="text-center group"
              >
                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-8 hover:bg-opacity-20 transition-all duration-300 transform hover:scale-105">
                  <div className="bg-white bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <div className="text-4xl font-bold text-white mb-2">
                    {stat.value}
                  </div>
                  <div className="text-xl font-semibold text-emerald-100 mb-2">
                    {stat.label}
                  </div>
                  <div className="text-emerald-200 text-sm">
                    {stat.description}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Stats;