import React from 'react';
import { Link } from 'react-router-dom';
import { Play, ArrowRight, Code, Brain, Trophy, Heart } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative bg-gradient-to-br from-emerald-50 via-white to-teal-50 py-20 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-20 left-10 w-20 h-20 bg-emerald-200 rounded-full blur-xl opacity-60"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-teal-200 rounded-full blur-xl opacity-60"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-medium">
                <Heart className="h-4 w-4" />
                <span>100% Free • No Subscriptions • Forever</span>
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Learn to
                <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                  {" "}code
                </span>
                <br />
                completely free
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Master programming, data science, and more with hands-on lessons, 
                real projects, and personalized learning paths. No hidden costs, no subscriptions - 
                just quality education for everyone.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/courses"
                className="inline-flex items-center justify-center space-x-2 bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transform hover:scale-105 transition-all shadow-lg hover:shadow-xl"
              >
                <span>Start Learning Free</span>
                <ArrowRight className="h-5 w-5" />
              </Link>
              <button className="inline-flex items-center justify-center space-x-2 border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-lg font-semibold hover:border-emerald-600 hover:text-emerald-600 transition-colors">
                <Play className="h-5 w-5" />
                <span>Watch Demo</span>
              </button>
            </div>

            {/* Free Features */}
            <div className="bg-white bg-opacity-70 backdrop-blur-sm rounded-2xl p-6 border border-emerald-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">What's included - All Free:</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                  <span className="text-gray-700">Interactive coding lessons</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                  <span className="text-gray-700">Real-world projects</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                  <span className="text-gray-700">Community support</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                  <span className="text-gray-700">Progress tracking</span>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-gray-200">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">500+</div>
                <div className="text-sm text-gray-600">Free Courses</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">2M+</div>
                <div className="text-sm text-gray-600">Happy Learners</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">$0</div>
                <div className="text-sm text-gray-600">Always Free</div>
              </div>
            </div>
          </div>

          {/* Right Content - Interactive Demo */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl p-6 transform rotate-3 hover:rotate-0 transition-transform duration-500">
              <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm">
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-gray-400 ml-4">welcome.py</span>
                </div>
                <div className="space-y-2">
                  <div className="text-purple-400">def <span className="text-blue-400">welcome_to_noolnest</span>():</div>
                  <div className="text-green-400 ml-4">    return "Welcome to free learning!"</div>
                  <div className="text-gray-400"># Start your journey:</div>
                  <div className="text-yellow-400">print(welcome_to_noolnest())</div>
                  <div className="text-green-300">→ Welcome to free learning!</div>
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Code className="h-5 w-5 text-emerald-600" />
                  <span className="text-sm font-medium text-gray-700">Python Basics</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  <span className="text-sm text-gray-600">Free Forever</span>
                </div>
              </div>
            </div>

            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-emerald-600 text-white p-3 rounded-lg shadow-lg animate-bounce">
              <Code className="h-6 w-6" />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-teal-600 text-white p-3 rounded-lg shadow-lg animate-pulse">
              <Heart className="h-6 w-6" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;