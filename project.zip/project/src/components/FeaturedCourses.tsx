import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Users, Star, ArrowRight, Code, Database, Palette, BarChart, Heart } from 'lucide-react';

const courses = [
  {
    id: 'python-basics',
    title: 'Python for Beginners',
    description: 'Learn Python programming from scratch with interactive exercises and real-world projects.',
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=400',
    icon: Code,
    level: 'Beginner',
    duration: '6 weeks',
    students: '125K',
    rating: 4.9,
    price: 'Free',
    color: 'emerald'
  },
  {
    id: 'web-development',
    title: 'Full-Stack Web Development',
    description: 'Build modern web applications with HTML, CSS, JavaScript, React, and Node.js.',
    image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400',
    icon: Code,
    level: 'Intermediate',
    duration: '12 weeks',
    students: '89K',
    rating: 4.8,
    price: 'Free',
    color: 'teal'
  },
  {
    id: 'data-science',
    title: 'Data Science with Python',
    description: 'Master data analysis, visualization, and machine learning with Python and popular libraries.',
    image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400',
    icon: BarChart,
    level: 'Advanced',
    duration: '10 weeks',
    students: '67K',
    rating: 4.9,
    price: 'Free',
    color: 'cyan'
  },
  {
    id: 'ui-ux-design',
    title: 'UI/UX Design Fundamentals',
    description: 'Create beautiful and user-friendly interfaces with design principles and modern tools.',
    image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400',
    icon: Palette,
    level: 'Beginner',
    duration: '8 weeks',
    students: '45K',
    rating: 4.7,
    price: 'Free',
    color: 'green'
  }
];

const FeaturedCourses = () => {
  const getColorClasses = (color: string) => {
    const colors = {
      emerald: 'from-emerald-500 to-emerald-600',
      teal: 'from-teal-500 to-teal-600',
      cyan: 'from-cyan-500 to-cyan-600',
      green: 'from-green-500 to-green-600'
    };
    return colors[color as keyof typeof colors] || colors.emerald;
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Heart className="h-4 w-4" />
            <span>All Courses Are Free</span>
          </div>
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Featured Free Courses
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Start your learning journey with our most popular courses, designed by industry experts 
            and available to everyone at no cost. No subscriptions, no hidden fees.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {courses.map((course) => {
            const IconComponent = course.icon;
            return (
              <Link
                key={course.id}
                to={`/course/${course.id}`}
                className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden border border-gray-100"
              >
                <div className="relative">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className={`absolute top-4 left-4 bg-gradient-to-r ${getColorClasses(course.color)} text-white p-2 rounded-lg`}>
                    <IconComponent className="h-5 w-5" />
                  </div>
                  <div className="absolute top-4 right-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
                    <Heart className="h-3 w-3" />
                    <span>Free</span>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
                      {course.level}
                    </span>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="text-sm font-medium text-gray-700">{course.rating}</span>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-emerald-600 transition-colors">
                    {course.title}
                  </h3>
                  <p className="text-gray-600 mb-4 line-clamp-2">
                    {course.description}
                  </p>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{course.students}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-emerald-600 font-semibold group-hover:text-emerald-700">
                      Start Learning Free
                    </span>
                    <ArrowRight className="h-5 w-5 text-emerald-600 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/courses"
            className="inline-flex items-center space-x-2 bg-emerald-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors"
          >
            <span>Browse All Free Courses</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedCourses;