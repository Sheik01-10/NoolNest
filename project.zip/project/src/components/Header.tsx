import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Menu, X, Search, User, Bell, Heart } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-2 rounded-lg group-hover:scale-105 transition-transform">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              NoolNest
            </span>
          </Link>

          {/* Free Badge */}
          <div className="hidden md:flex items-center bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-sm font-medium">
            <Heart className="h-4 w-4 mr-1" />
            <span>100% Free Forever</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/courses" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">
              Courses
            </Link>
            <Link to="/paths" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">
              Learning Paths
            </Link>
            <Link to="/practice" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">
              Practice
            </Link>
            <Link to="/community" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">
              Community
            </Link>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search free courses, topics..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="p-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors">
              <Bell className="h-5 w-5" />
            </button>
            <button className="flex items-center space-x-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors">
              <User className="h-4 w-4" />
              <span>Join Free</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg text-gray-600 hover:text-emerald-600 hover:bg-emerald-50"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <div className="bg-emerald-50 text-emerald-700 px-3 py-2 rounded-lg text-sm font-medium text-center">
                <Heart className="h-4 w-4 inline mr-1" />
                100% Free Forever
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search free courses..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
              <Link to="/courses" className="text-gray-700 hover:text-emerald-600 font-medium py-2">
                Courses
              </Link>
              <Link to="/paths" className="text-gray-700 hover:text-emerald-600 font-medium py-2">
                Learning Paths
              </Link>
              <Link to="/practice" className="text-gray-700 hover:text-emerald-600 font-medium py-2">
                Practice
              </Link>
              <Link to="/community" className="text-gray-700 hover:text-emerald-600 font-medium py-2">
                Community
              </Link>
              <button className="flex items-center justify-center space-x-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors">
                <User className="h-4 w-4" />
                <span>Join Free</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;