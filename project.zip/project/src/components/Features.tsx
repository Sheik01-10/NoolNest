import React from 'react';
import { Code, Users, Trophy, Zap, BookOpen, Target, Heart, Gift } from 'lucide-react';

const features = [
  {
    icon: Gift,
    title: 'Completely Free',
    description: 'All courses, projects, and features are free forever. No subscriptions, no hidden costs.',
    color: 'emerald'
  },
  {
    icon: Code,
    title: 'Interactive Coding',
    description: 'Write and run code directly in your browser with our interactive coding environment.',
    color: 'teal'
  },
  {
    icon: Users,
    title: 'Community Support',
    description: 'Connect with fellow learners, get help, and share your progress in our vibrant community.',
    color: 'cyan'
  },
  {
    icon: Trophy,
    title: 'Earn Certificates',
    description: 'Complete courses and earn certificates to showcase your skills - all at no cost.',
    color: 'green'
  },
  {
    icon: Zap,
    title: 'Personalized Learning',
    description: 'AI-powered recommendations adapt to your learning style and pace for optimal results.',
    color: 'lime'
  },
  {
    icon: BookOpen,
    title: 'Real Projects',
    description: 'Build portfolio-worthy projects that demonstrate your skills to potential employers.',
    color: 'emerald'
  }
];

const Features = () => {
  const getColorClasses = (color: string) => {
    const colors = {
      emerald: 'bg-emerald-100 text-emerald-600',
      teal: 'bg-teal-100 text-teal-600',
      cyan: 'bg-cyan-100 text-cyan-600',
      green: 'bg-green-100 text-green-600',
      lime: 'bg-lime-100 text-lime-600'
    };
    return colors[color as keyof typeof colors] || colors.emerald;
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Heart className="h-4 w-4" />
            <span>Free Education for Everyone</span>
          </div>
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Why Choose NoolNest?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We believe quality education should be accessible to everyone. That's why we provide 
            everything you need to master new skills completely free, forever.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100"
              >
                <div className={`w-12 h-12 rounded-lg ${getColorClasses(feature.color)} flex items-center justify-center mb-6`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Free Promise */}
        <div className="mt-16 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-8 text-center text-white">
          <div className="max-w-3xl mx-auto">
            <Heart className="h-12 w-12 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-4">Our Promise to You</h3>
            <p className="text-lg text-emerald-100 mb-6">
              NoolNest will always be free. We're committed to making quality education accessible 
              to everyone, regardless of their financial situation. No ads, no subscriptions, no catch.
            </p>
            <div className="flex items-center justify-center space-x-8 text-emerald-100">
              <div className="text-center">
                <div className="text-2xl font-bold">$0</div>
                <div className="text-sm">Course Fees</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">$0</div>
                <div className="text-sm">Subscriptions</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">$0</div>
                <div className="text-sm">Hidden Costs</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;