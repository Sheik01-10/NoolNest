import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Play, CheckCircle, Code, BookOpen, Heart } from 'lucide-react';

const lessonData = {
  1: {
    title: 'Introduction to Python',
    description: 'Welcome to Python! In this lesson, you\'ll learn what Python is, why it\'s popular, and write your first Python program.',
    content: `
# Welcome to Python Programming!

Python is a high-level, interpreted programming language known for its simplicity and readability. 
It's widely used in web development, data science, artificial intelligence, and automation.

## Why Python?

- **Easy to learn**: Python's syntax is clean and intuitive
- **Versatile**: Used in many domains from web development to AI
- **Large community**: Extensive libraries and community support
- **Cross-platform**: Runs on Windows, macOS, and Linux

## Your First Python Program

Let's start with the traditional "Hello, World!" program:

\`\`\`python
print("Hello, World!")
\`\`\`

This simple line of code will output "Hello, World!" to the screen.
    `,
    codeExample: `# Your first Python program
print("Hello, World!")

# Try modifying the message
print("Welcome to NoolNest - Free Python learning!")

# You can also use variables
message = "Python is awesome and free to learn!"
print(message)`,
    exercises: [
      {
        question: 'Write a Python program that prints your name.',
        solution: 'print("Your Name")'
      },
      {
        question: 'Create a variable called "age" and print it.',
        solution: 'age = 25\nprint(age)'
      }
    ]
  }
};

const LessonPage = () => {
  const { courseId, lessonId } = useParams();
  const [activeTab, setActiveTab] = useState('content');
  const [userCode, setUserCode] = useState('# Write your code here - completely free!\nprint("Hello, NoolNest!")');
  const [output, setOutput] = useState('');

  const lesson = lessonData[parseInt(lessonId || '1') as keyof typeof lessonData];

  if (!lesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Lesson Not Found</h1>
          <Link to={`/course/${courseId}`} className="text-emerald-600 hover:text-emerald-700">
            Return to Course
          </Link>
        </div>
      </div>
    );
  }

  const runCode = () => {
    // Simulate code execution (in a real app, this would use a code execution service)
    try {
      // Simple simulation for print statements
      const printMatches = userCode.match(/print\((.*?)\)/g);
      if (printMatches) {
        const outputs = printMatches.map(match => {
          const content = match.match(/print\((.*?)\)/)?.[1] || '';
          return content.replace(/['"]/g, '');
        });
        setOutput(outputs.join('\n'));
      } else {
        setOutput('No output');
      }
    } catch (error) {
      setOutput('Error: Invalid syntax');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link
                to={`/course/${courseId}`}
                className="flex items-center space-x-2 text-gray-600 hover:text-emerald-600 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>Back to Course</span>
              </Link>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="text-lg font-semibold text-gray-900">{lesson.title}</h1>
              <div className="flex items-center space-x-1 bg-emerald-100 text-emerald-700 px-2 py-1 rounded text-xs font-medium">
                <Heart className="h-3 w-3" />
                <span>Free</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                <CheckCircle className="h-4 w-4" />
                <span>Mark Complete</span>
              </button>
              <button className="flex items-center space-x-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors">
                <span>Next Lesson</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-8 h-[calc(100vh-200px)]">
          {/* Left Panel - Content */}
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 flex flex-col">
            <div className="border-b border-gray-200">
              <nav className="flex space-x-8 px-6">
                <button
                  onClick={() => setActiveTab('content')}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'content'
                      ? 'border-emerald-500 text-emerald-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <BookOpen className="h-4 w-4" />
                    <span>Lesson</span>
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('exercises')}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'exercises'
                      ? 'border-emerald-500 text-emerald-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Code className="h-4 w-4" />
                    <span>Exercises</span>
                  </div>
                </button>
              </nav>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              {activeTab === 'content' && (
                <div className="prose prose-emerald max-w-none">
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 mb-6">
                    <div className="flex items-center space-x-2 text-emerald-700 mb-2">
                      <Heart className="h-4 w-4" />
                      <span className="font-semibold">Free Lesson</span>
                    </div>
                    <p className="text-emerald-600 text-sm">
                      This lesson is completely free. No payment or subscription required.
                    </p>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">{lesson.title}</h2>
                  <p className="text-gray-600 mb-6">{lesson.description}</p>
                  <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
                    {lesson.content}
                  </div>
                </div>
              )}

              {activeTab === 'exercises' && (
                <div className="space-y-6">
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2 text-emerald-700 mb-2">
                      <Heart className="h-4 w-4" />
                      <span className="font-semibold">Free Practice Exercises</span>
                    </div>
                    <p className="text-emerald-600 text-sm">
                      Practice coding with these free exercises. No limits, no restrictions.
                    </p>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Practice Exercises</h3>
                  {lesson.exercises.map((exercise, index) => (
                    <div key={index} className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Exercise {index + 1}
                      </h4>
                      <p className="text-gray-700 mb-3">{exercise.question}</p>
                      <details className="text-sm">
                        <summary className="cursor-pointer text-emerald-600 hover:text-emerald-700">
                          Show Solution
                        </summary>
                        <pre className="mt-2 bg-gray-800 text-green-400 p-3 rounded text-xs overflow-x-auto">
                          {exercise.solution}
                        </pre>
                      </details>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Panel - Code Editor */}
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 flex flex-col">
            <div className="border-b border-gray-200 px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <h3 className="text-lg font-semibold text-gray-900">Free Code Editor</h3>
                  <div className="flex items-center space-x-1 bg-emerald-100 text-emerald-700 px-2 py-1 rounded text-xs font-medium">
                    <Heart className="h-3 w-3" />
                    <span>No Limits</span>
                  </div>
                </div>
                <button
                  onClick={runCode}
                  className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Play className="h-4 w-4" />
                  <span>Run Code</span>
                </button>
              </div>
            </div>

            <div className="flex-1 flex flex-col">
              {/* Code Editor */}
              <div className="flex-1 relative">
                <textarea
                  value={userCode}
                  onChange={(e) => setUserCode(e.target.value)}
                  className="w-full h-full p-4 font-mono text-sm bg-gray-900 text-green-400 resize-none focus:outline-none"
                  placeholder="Write your Python code here - completely free!"
                />
              </div>

              {/* Output */}
              <div className="border-t border-gray-200 bg-gray-50">
                <div className="px-4 py-2 border-b border-gray-200">
                  <h4 className="text-sm font-semibold text-gray-700">Output</h4>
                </div>
                <div className="p-4 h-32 overflow-y-auto">
                  <pre className="text-sm text-gray-800 whitespace-pre-wrap">
                    {output || 'Click "Run Code" to see output - completely free!'}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LessonPage;