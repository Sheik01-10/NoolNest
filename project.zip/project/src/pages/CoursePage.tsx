import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Play, Clock, Users, Star, CheckCircle, Lock, ArrowRight, Heart } from 'lucide-react';

const courseData = {
  'python-basics': {
    title: 'Python for Beginners',
    description: 'Learn Python programming from scratch with interactive exercises and real-world projects. This comprehensive course covers everything from basic syntax to advanced concepts.',
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=800',
    instructor: 'Dr. Sarah Johnson',
    instructorImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=200',
    duration: '6 weeks',
    students: '125,432',
    rating: 4.9,
    reviews: 8234,
    level: 'Beginner',
    price: 'Free',
    lessons: [
      { id: 1, title: 'Introduction to Python', duration: '15 min', completed: false, locked: false },
      { id: 2, title: 'Variables and Data Types', duration: '20 min', completed: false, locked: false },
      { id: 3, title: 'Control Structures', duration: '25 min', completed: false, locked: true },
      { id: 4, title: 'Functions and Modules', duration: '30 min', completed: false, locked: true },
      { id: 5, title: 'File Handling', duration: '22 min', completed: false, locked: true },
      { id: 6, title: 'Error Handling', duration: '18 min', completed: false, locked: true },
      { id: 7, title: 'Object-Oriented Programming', duration: '35 min', completed: false, locked: true },
      { id: 8, title: 'Final Project', duration: '45 min', completed: false, locked: true }
    ]
  }
};

const CoursePage = () => {
  const { courseId } = useParams();
  const course = courseData[courseId as keyof typeof courseData];

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Course Not Found</h1>
          <Link to="/" className="text-emerald-600 hover:text-emerald-700">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="flex items-center space-x-2">
                <span className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm font-medium">
                  {course.level}
                </span>
                <span className="bg-emerald-500 px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
                  <Heart className="h-3 w-3" />
                  <span>Free Forever</span>
                </span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold leading-tight">
                {course.title}
              </h1>
              <p className="text-xl text-emerald-100 leading-relaxed">
                {course.description}
              </p>
              
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <img
                    src={course.instructorImage}
                    alt={course.instructor}
                    className="w-10 h-10 rounded-full"
                  />
                  <span className="font-medium">{course.instructor}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="font-medium">{course.rating}</span>
                  <span className="text-emerald-200">({course.reviews} reviews)</span>
                </div>
              </div>

              <div className="flex items-center space-x-8 text-emerald-100">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>{course.students} students</span>
                </div>
              </div>

              <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center space-x-2 text-emerald-200 mb-2">
                  <Heart className="h-4 w-4" />
                  <span className="font-semibold">100% Free Course</span>
                </div>
                <p className="text-emerald-100 text-sm">
                  No payment required. No subscriptions. Just quality education for everyone.
                </p>
              </div>

              <button className="bg-white text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center space-x-2">
                <Play className="h-5 w-5" />
                <span>Start Learning Free</span>
              </button>
            </div>

            <div className="relative">
              <img
                src={course.image}
                alt={course.title}
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 rounded-2xl flex items-center justify-center">
                <button className="bg-white bg-opacity-90 hover:bg-opacity-100 text-gray-900 p-4 rounded-full transition-all transform hover:scale-110">
                  <Play className="h-8 w-8" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Course Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Course Curriculum</h2>
              <div className="space-y-4">
                {course.lessons.map((lesson) => (
                  <div
                    key={lesson.id}
                    className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          {lesson.completed ? (
                            <CheckCircle className="h-6 w-6 text-green-500" />
                          ) : lesson.locked ? (
                            <Lock className="h-6 w-6 text-gray-400" />
                          ) : (
                            <Play className="h-6 w-6 text-emerald-600" />
                          )}
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{lesson.title}</h3>
                          <p className="text-sm text-gray-600">{lesson.duration}</p>
                        </div>
                      </div>
                      {!lesson.locked && (
                        <Link
                          to={`/course/${courseId}/lesson/${lesson.id}`}
                          className="text-emerald-600 hover:text-emerald-700 font-medium flex items-center space-x-1"
                        >
                          <span>Start Free</span>
                          <ArrowRight className="h-4 w-4" />
                        </Link>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">What You'll Learn</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  'Python syntax and fundamentals',
                  'Data types and variables',
                  'Control flow and loops',
                  'Functions and modules',
                  'File handling and I/O',
                  'Error handling and debugging',
                  'Object-oriented programming',
                  'Real-world project development'
                ].map((item, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Course Progress</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>Completed</span>
                    <span>0/8 lessons</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '0%' }}></div>
                  </div>
                </div>
                <div className="text-center">
                  <button className="w-full bg-emerald-600 text-white py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors">
                    Continue Learning Free
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl shadow-lg p-6 border border-emerald-200">
              <div className="flex items-center space-x-2 text-emerald-700 mb-4">
                <Heart className="h-5 w-5" />
                <h3 className="text-lg font-bold">Free Course Promise</h3>
              </div>
              <ul className="space-y-2 text-sm text-emerald-600">
                <li>✓ No payment required</li>
                <li>✓ No subscriptions</li>
                <li>✓ No hidden costs</li>
                <li>✓ Full access forever</li>
                <li>✓ Certificate included</li>
              </ul>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Instructor</h3>
              <div className="flex items-center space-x-4 mb-4">
                <img
                  src={course.instructorImage}
                  alt={course.instructor}
                  className="w-16 h-16 rounded-full"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{course.instructor}</h4>
                  <p className="text-sm text-gray-600">Senior Python Developer</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm">
                Dr. Johnson has over 10 years of experience in Python development and has taught 
                programming to thousands of students worldwide - all for free.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoursePage;