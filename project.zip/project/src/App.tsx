import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import FeaturedCourses from './components/FeaturedCourses';
import Features from './components/Features';
import Stats from './components/Stats';
import Footer from './components/Footer';
import CoursePage from './pages/CoursePage';
import LessonPage from './pages/LessonPage';

function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedCourses />
      <Features />
      <Stats />
    </>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/course/:courseId" element={<CoursePage />} />
          <Route path="/course/:courseId/lesson/:lessonId" element={<LessonPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;